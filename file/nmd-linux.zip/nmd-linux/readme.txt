###  INSTALL
1. chmod +x install.sh
2. sudo ./install.sh

###  DOWNLOAD
1. chmod +x download.sh
2. ./download.sh

###  How To ChromeOS
1. 設定 > 詳細設定 > デベロッパー を開く
2. Linux開発環境をオンにする
3.  nmd For Linuxをインストール > ###  INSTALLを参照