###  INSTALL
  1.ChromeOSの場合
	1.設定 > 詳細設定 > デベロッパー を開く
	2.Linux開発環境をオンにする
	3.install-chrome.txtのテキストをコピー&ターミナルにペーストして nmd For Linux をインストール

  2.ChromeOS以外の場合
	install-main.txtのテキストをコピー&ターミナルにペーストして nmd For Linux をインストール
	
###  DOWNLOAD
	yt-dlp [URL]
	サイト一覧: https://github.com/yt-dlp/yt-dlp/blob/master/supportedsites.md