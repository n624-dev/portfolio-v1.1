#!/bin/bash

# UTF-8で文字エンコーディングを設定
export LC_ALL=C.UTF-8

# yt-dlpのバージョンを取得
VERSION=$(yt-dlp --version | head -n 1 | cut -d " " -f 2)
echo "yt-dlp version $VERSION"
echo "アップデートを確認中"
yt-dlp --update

clear

# URLの入力を受け取る
while true; do
    echo "+-------------------------------------------------------+"
    echo "URLを入力してください。"
    echo "+-------------------------------------------------------+"
    read -p "URL: " INPUT_STR

    if [ -n "$INPUT_STR" ]; then
        break
    fi
done

clear

# URLの確認
while true; do
    echo "+-------------------------------------------------------+"
    echo "URLは[$INPUT_STR]でよろしいですか?"
    echo "(Y / N)"
    echo "+-------------------------------------------------------+"
    read -p "確認 (Y / N): " CONF_SELECT

    if [ "$CONF_SELECT" == "Y" ] || [ "$CONF_SELECT" == "y" ]; then
        break
    fi
done

clear

# ダウンロード
echo "+-------------------------------------------------------+"
echo "DOWNLOADING"
echo "+-------------------------------------------------------+"
yt-dlp -o "%(title)s" -f mergeall/bv*ba/b "$INPUT_STR"
read -p "ダウンロードが完了しました。続行するにはEnterキーを押してください。"

clear

# 終了
echo "+-------------------------------------------------------+"
echo "完了しました。"
echo "+-------------------------------------------------------+"
read -p "続行するにはEnterキーを押してください。"