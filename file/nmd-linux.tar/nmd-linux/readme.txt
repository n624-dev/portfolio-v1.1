###  INSTALL
1. install.txtをすべてコピー   #  この下に同じ内容のものがあります。
2. ターミナルにすべて貼り付けし Enterを押す  #  一文ずつ実行でも可
3.  実行中に再起動するので sudo apt install yt-dlp を再度実行
4. yt-dlp --version を実行して20XX.XX.XXと表示されたらインストール完了
エラーが出る場合 install-old.sh を実行してみてください

###  DOWNLOAD
yt-dlp [URL]
サイト一覧: https://github.com/yt-dlp/yt-dlp/blob/master/supportedsites.md

###  How To ChromeOS
1. 設定 > 詳細設定 > デベロッパー を開く
2. Linux開発環境をオンにする
3.  nmd For Linuxをインストール  #  ###  INSTALLを参照

### install.txt
sudo apt -y update
sudo apt -yV upgrade
sudo /sbin/shutdown -r now
sudo apt install yt-dlp
yt-dlp --version