###  INSTALL
1. chmod +x install.sh
2. sudo ./install.sh
エラーが出る場合 install-old.sh を実行してみてください

###  DOWNLOAD
yt-dlp [URL]
サイト一覧: https://github.com/yt-dlp/yt-dlp/blob/master/supportedsites.md

###  How To ChromeOS
1. 設定 > 詳細設定 > デベロッパー を開く
2. Linux開発環境をオンにする
3.  nmd For Linuxをインストール > ###  INSTALLを参照