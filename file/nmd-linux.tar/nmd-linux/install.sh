sudo apt -y update
sudo apt -yV upgrade
sudo /sbin/shutdown -r now
sudo apt install yt-dlp
yt-dlp --version